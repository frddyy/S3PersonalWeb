import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  Typography,
  TextField,
  MenuItem,
  useMediaQuery,
} from "@mui/material";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";
import Header from "../../components/header";

const EditOrganizationForm = () => {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const navigate = useNavigate();
  const { organizationId } = useParams();

  const [organizationData, setOrganizationData] = useState({
    name_org: "",
    image: "",
    start_year: "",
    end_year: "",
    role: "",
    jobdesc: "",
  });
  const [msg, setMsg] = useState("");

  useEffect(() => {
    // Get user data by userId and populate the form fields
    const getOrganizationById = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/organizations/${organizationId}`);
        const organizationData = response.data;
        setOrganizationData(organizationData || {}); // Berikan nilai awal sebagai objek kosong jika userData null
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    getOrganizationById();
  }, [organizationId]);

  const updateOrganization = async (e) => {
    e.preventDefault();
    try {
      const updatedData = {};
      for (const key in organizationData) {
        if (organizationData[key] !== "") {
          updatedData[key] = organizationData[key];
        }
      }

      await axios.patch(`http://localhost:5000/identities/1/organizations/${organizationId}`, updatedData);
      setMsg("Perubahan Data Organisasi Berhasil");
      navigate("/organizations");
    } catch (error) {
      if (error.response) {
        setMsg(error.response.data.msg);
      } else {
        setMsg("Terjadi kesalahan saat memperbarui data organisasi.");
      }
    }
  };

  const handleFieldChange = (e) => {
    const { name, value } = e.target;
    setOrganizationData({ ...organizationData, [name]: value });
  };

  return (
    <Box m="20px">
      <Header title="EDIT ORGANIZATION" subtitle="Edit Data Organisasi" />
      <Typography variant="h6" color="error">
        {msg}
      </Typography>
      <form onSubmit={updateOrganization}>
        <Box
          display="grid"
          gap="30px"
          gridTemplateColumns={isNonMobile ? "repeat(4, minmax(0, 1fr))" : "1fr"}
        >
          <TextField
            fullWidth
            variant="filled"
            type="text"
            id="name_org"
            name="name_org"
            label="name_org"
            value={organizationData.name_org|| ""}
            onChange={handleFieldChange}
            sx={{ gridColumn: "span 4" }}
          />

          <TextField
            fullWidth
            variant="filled"
            type="text"
            id="image"
            name="image"
            label="image"
            value={organizationData.image || ""}
            onChange={handleFieldChange}
            sx={{ gridColumn: "span 4" }}
          />

          <TextField
            fullWidth
            variant="filled"
            type="text"
            id="start_year"
            name="start_year"
            label="start_year"
            value={organizationData.start_year || ""}
            onChange={handleFieldChange}
            sx={{ gridColumn: "span 4" }}
          />

          <TextField
            fullWidth
            variant="filled"
            type="text"
            id="end_year"
            name="end_year"
            label="end_year"
            value={organizationData.end_year || ""}
            onChange={handleFieldChange}
            sx={{ gridColumn: "span 4" }}
          />

          <TextField
            fullWidth
            variant="filled"
            type="text"
            id="role"
            name="role"
            label="role"
            value={organizationData.role || ""}
            onChange={handleFieldChange}
            sx={{ gridColumn: "span 4" }}
          />            

          <TextField
            fullWidth
            variant="filled"
            type="text"
            id="jobdesc"
            name="jobdesc"
            label="jobdesc"
            value={organizationData.jobdesc || ""}
            onChange={handleFieldChange}
            sx={{ gridColumn: "span 4" }}
          />

        </Box>

        <Box display="flex" justifyContent="end" mt="20px">
          <Button type="submit" color="secondary" variant="contained">
            Update User
          </Button>
        </Box>
      </form>
    </Box>
  );
};

export default EditOrganizationForm;

